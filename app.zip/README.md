# Remove politica do facebook

Remove as notificas de politica do facebook.


Chrome Store: https://chrome.google.com/webstore/detail/pausa-politica-no-faceboo/hicbmloidfjfnkpoiclkhgepimjenakb
